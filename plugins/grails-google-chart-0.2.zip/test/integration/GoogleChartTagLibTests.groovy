class GoogleChartTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}